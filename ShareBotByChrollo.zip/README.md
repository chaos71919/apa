<h1 align="center">💎TMB {TikTok Mass Botting}</h1>

<p align='center'>
  <b>Star ⭐ if you want more</b><br>
</p>

Join here if you need help ! https://discord.gg/R9BUFWFeHz
https://discord.gg/R9BUFWFeHz
PATCHED EVENTUALLY JOIN DISCORD 4 HELP
ITS SLOW FOR NOW BUT IT WILL BE FASTER SOON. BETTER SLOW THAN PATCHED
WERE FIXIING IT
## Features
```js
  * View botting
  * Share botting (not patched you can do a ton of share)
  * Easy to use, Fast
  * Compatible Linux / Win / (didnt tested for macos)
  * Proxy Scrapper integrated
```

## Installation
```
  * pip install requests pystyle
```

##  Usage:
```
  * python <ShareBot.py or ViewBot.py>
  * paste video url
  * choose amount
  * enter yes or no if you want to scrap proxie
  * enter proxy type you put in Proxies.txt
  * enter proxy timeout | choose 3 if you want a good timeout
  * enter thread | more thread = faster but make your computer slower | choose 100~1000
```

## Tricks
```js
  * Use on vps (Faster !)
  * Run 3 times one with http proxy type, one with socks4 proxy type and same for socks5
```


##  Credits:
 > [!]
 <br>Discord : (https://discord.gg/R9BUFWFeHz)
